/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package evenorodd;

/**
 *
 * @author THAPELI
 */
import java.util.Scanner;
public class EvenOrOdd {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner num = new Scanner(System.in);
        System.out.println("enter any number");
        int number = num.nextInt();
        if(number % 2 == 1){
            System.out.println("the number "+num+" is an odd number ");
            
        }else{
        System.out.println("the number "+number+" is and even number ");
        }
        num.close();
    }
    
}
