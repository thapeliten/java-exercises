/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package charcheck;

/**
 *
 * @author THAPELI
 */
import java.util.Scanner;
public class CharCheck {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner letter = new Scanner(System.in);
         System.out.println(" Enetr a letter");
      char holder = letter.next().charAt(0);
        if(holder == 'a' || holder == 'e' || holder == 'i' || holder == 'o' || holder == 'u'){
        System.out.println(holder +" is a vowel");
        }else{
         System.out.println(holder +" is a consonant");
        }
        letter.close();
    }
    
}
