/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package largestofthreenumbers;

/**
 *
 * @author THAPELI
 */
import java.util.Scanner;
public class LargestOfThreeNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner num = new Scanner(System.in);
        System.out.println("enter fisrt number a");
        double a = num.nextDouble();
        System.out.println("enter second number b");
        double b = num.nextDouble();
        System.out.println("enter third number c");
        double c = num.nextDouble();
        
        if(a < b && b < c){
        System.out.println( c + " c is the largest");
       
        }
        if(b>a && b>c){
            System.out.println(b +" b is the largest ");
        }
        if(a > b && b > c){
        System.out.println(a+" a is the largest");
        }
        num.close();
    }
    
}
