package classes;

  
public class Classes {
    
    public static void main(String[] args){
    
       student st = new student();
       st.name ="Mosa";
       st.std_id =1212;
      st.instructor ="Bohlale";
      st.instructor ="me";
      
      System.out.println(st.name + st.std_id+st.instructor);
    int i = 4;
    System.out.println(i);
    }



}
class student{

int std_id;
String name;
static String instructor;


}