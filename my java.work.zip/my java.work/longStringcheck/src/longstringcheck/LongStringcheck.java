/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package longstringcheck;

/**
 *
 * @author THAPELI
 */
public class LongStringcheck {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String sentence = "Java makes programming interesting and enjoyable";
        String longest = Longest(sentence);
        
        System.out.println("Sentence: " + sentence);
        System.out.println("Longest word: " + longest);
    }
    public static String Longest(String sentence){
    
        String[] words = sentence.split("\\s+");
        String longest = "";
         for (String word : words) {
            if (word.length() > longest.length()) {
                longest = word;
            }
        }
         return longest;
    }
    
}
