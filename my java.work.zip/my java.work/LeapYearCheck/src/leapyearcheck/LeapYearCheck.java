
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package leapyearcheck;

/**
 *
 * @author THAPELI
 */
import java.util.Scanner;
public class LeapYearCheck {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner year = new Scanner(System.in);
        System.out.println( "enter year");
        int leap = year.nextInt();
        if (leap % 4 == 0){
        System.out.println(leap + " is a leap year");
        }else{
        System.out.println(leap + " is NOT a leap year");
        }
        year.close();
        
    }
    
}
