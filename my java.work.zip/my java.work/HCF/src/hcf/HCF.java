/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hcf;

/**
 *
 * @author THAPELI
 */
public class HCF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
          int num1 = 12, num2 = 80;
        System.out.println("HCF of " + num1 + " and " + num2 + " is: " + GCD(num1, num2));
    }
   
    public static int GCD(int a, int b){
    
        while (b != 0) {
            int temp = b;

            b = a % b;
           
            a = temp;
            
        }
        return a;
        
    }
}
