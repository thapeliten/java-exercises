/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package constructor;

/**
 *
 * @author THAPELI
 */
 
public class Constructor {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        student s1 = new student(25001, "Jane", "Computing", new double[]{85, 90, 88});
        student s2 = new student(25002, "Carlos", "Mobile Computing", new double[]{78, 82, 80});
        student s3 = new student(25003, "Lirontsho", "Business Admin", new double[]{92, 88, 95});
        
         s1.displayInfo();
        s2.displayInfo();
        s3.displayInfo();
    }
    
}
class student{
   int  student_id;
    String name;
   String  programe_name;
    double[]  grades;
    student(int student_id, String name, String programe_name,  double[] grades){
   this.student_id = student_id;
   this.name = name;
   this.programe_name = programe_name;
   this.grades = grades;
    }
    
    public double calculateGPA() {
        double sum = 0;
        for (double grade : grades) {
            sum += grade;
        }
        return sum / grades.length; // average
    }
    
  void displayInfo(){
        System.out.println("Student Id: "+ student_id);
        System.out.println("Name: "+ name);
        System.out.println("Programmename: "+ programe_name);
         for (double grade : grades) {
            System.out.print(grade + " ");
        }
         System.out.println("\nGPA: " + calculateGPA());
        System.out.println("-------------------------");
    }  
}