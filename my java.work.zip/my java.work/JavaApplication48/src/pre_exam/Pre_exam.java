package pre_exam;

public class Pre_exam {
    public static void main(String[] args) {
        student stud = new student("Ten ten", 1324, new int[]{81, 91, 72, 83, 73});
        stud.enroll("Computing"); // using the interface method
        stud.displayDetails();
        stud.finalGrade();
    }
}

class person {
    String name;
    int id;

    person(String name, int id) {
        this.name = name;
        this.id = id;
    }

    void displayDetails() {
        System.out.println(name + " " + id);
    }
}

class student extends person implements Enrollable {
    private int[] grade;
    private String program;

    public student(String name, int id) {
        super(name, id);
        this.grade = new int[5];
    }

    student(String name, int id, int[] grade) {
        super(name, id);
        this.grade = grade; // ✅ FIXED
    }

    @Override
    void displayDetails() {
        super.displayDetails();
        System.out.println("Program: " + program);
        for (int g : grade) {
            System.out.println(g);
        }
    }

    double finalGrade() {
        int total = 0;
        for (int g : grade) {
            total += g;
        }
        double av = (double) total / grade.length;
        System.out.println("Average: " + av);

        if (av >= 80) {
            System.out.println("Letter grade: A");
        } else if (av >= 65) {
            System.out.println("Letter grade: B");
        } else if (av >= 50) {
            System.out.println("Letter grade: C");
        } else {
            System.out.println("Letter grade: F");
        }

        return av;
    }

    // ✅ Implementing Enrollable
    @Override
    public void enroll(String enrollmentCourse) {
        this.program = enrollmentCourse;
        System.out.println("Enrolled in: " + enrollmentCourse);
    }
}

interface Enrollable {
    void enroll(String EnrollmentCourse);
}
