/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package charfrequency;

/**
 *
 * @author THAPELI
 */
import java.util.HashMap;
public class CharFrequency {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         String input = "hheello worrld";
        HashMap<Character, Integer> freqMap = new HashMap<>();

        for (char ch : input.toCharArray()) {
            if (ch != ' ') { // Skip spaces
                freqMap.put(ch, freqMap.getOrDefault(ch, 0) + 1);
            }
        }

        // Print the frequency of each character
        for (char ch : freqMap.keySet()) {
            System.out.println(ch + " : " + freqMap.get(ch));
        }
    }
    
}
