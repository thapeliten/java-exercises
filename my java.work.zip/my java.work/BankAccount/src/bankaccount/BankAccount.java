/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bankaccount;

/**
 *
 * @author THAPELI
 */
import java.util.Scanner;
public class BankAccount {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner choice = new Scanner(System.in);
        System.out.println("welcome to your bank account ");
        System.out.println("1. withdraw");
        System.out.println("2. deposit");
        int input = choice.nextInt();
            switch(input){
                case 1 ->{
                System.out.print("how much would you like withdraw");
                int num = choice.nextInt();
                withdraw(num);
                }
                case 2 ->{
                System.out.print("how much would you like deposit");
                int num = choice.nextInt();
                deposit(num);
                }
               
            }
             choice.close();

    }
    
    static int  withdraw(int num){
        int balance = 10000;
        int bal = balance - num;
        if(num > balance ){
         System.out.print("insuficient balance ");
        }
    System.out.print("withdraw of "+ num + "successful");
    System.out.print("your remaining balance is: "+ bal);
    return bal;
    }
    static int deposit(int num){
         int balance = 10000;
        int bal = balance + num;
    System.out.print("deposit of "+ num + "successful");
    System.out.print("your new balance is :"+ bal);
    return bal;
    }
}
