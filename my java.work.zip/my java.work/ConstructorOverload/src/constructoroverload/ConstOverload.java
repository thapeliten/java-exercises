package constructoroverload;

public class ConstOverload {

    String name;
    String surname;
    int Age; 
    String status;

    
    ConstOverload(String name, String surname){
        this.name = name;
        this.surname = surname;
    }

   
    ConstOverload(String name, String surname, int Age){
        this.name = name;
        this.surname = surname;
        this.Age = Age;
    }

   
    ConstOverload(String name, String surname, int Age, String status){
        this.name = name;
        this.surname = surname;
        this.Age = Age;
        this.status = status;
    }

   
    public void displayDetails(){
        System.out.println("Name: " + name);
        System.out.println("Surname: " + surname);
        System.out.println("Age: " + Age);
        System.out.println("Status: " + status);
        System.out.println("-----------------------");
    }

    public static void main(String[] args) {
        
        ConstOverload person1 = new ConstOverload("John", "Smith");

        
        ConstOverload person2 = new ConstOverload("Mary", "Johnson", 25);

        
        ConstOverload person3 = new ConstOverload("Thapeli", "Thene", 30, "Single");

        
        person1.displayDetails();
        person2.displayDetails();
        person3.displayDetails();
    }
}
