/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfces;

/**
 *
 * @author THAPELI
 */
import java.util.*;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.TreeSet;
import java.util.Iterator;
import java.util.Set;

public class Interfces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Set<Integer> numbers = new TreeSet<>(); //TreeSet
        numbers.add(10);
        numbers.add(20);
        numbers.add(3);

        // 1. iterator 
        System.out.println("\nUsing the iterator keyword");
        Iterator<Integer> it = numbers.iterator();
        while (it.hasNext()) {

            System.out.println(it.next());
        }
        // Enhanced for loop
        System.out.println("");
        System.out.println("\nUsing enhanced for loop");
        for (int num : numbers) {

            System.out.println(num);
        }
        System.out.println("");
        // 3. forEach with lambda (Java 8+)

        System.out.println("\nUsing forEach method:");
        numbers.forEach(n -> System.out.println(n));

    }
}
