/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demojdbc;

/**
 *
 * @author THAPELI
 */
import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
public class DemoJDBC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        String url = "jdbc:mysql://localhost:3306/students";
        String username = "root";
        String password = "";
       
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(url,username,password);
        Statement st = con.createStatement();
        
        String query = "INSERT INTO `students info`(`Student_ID`, `Name`) VALUES (3,'Mpho')";
        String query2 = "SELECT * FROM `students info`";
       // String query3 = "UPDATE `students info` SET Name ='Tekane' WHERE Student_ID=1";
        //String query4 = "DELETE FROM `students info` where Student_ID=2";
        
        //ResultSet rs = st.executeQuery(query2);
        
       st.executeUpdate(query);
      // st.executeUpdate(query2);
       /*while( rs.next()){
       
        String Name = rs.getString("name");
        int id = rs.getInt("Student_ID");
        System.out.println(Name +" "+ id +" "+ Date.valueOf(LocalDate.now()));
        
       }*/
        st.close();
        con.close();
    }
    
}
