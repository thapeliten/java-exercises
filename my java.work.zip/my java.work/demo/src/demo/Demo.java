
package demo;
import java.util.*;
public class Demo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       /*
       List<String> cars =new ArrayList<>();
       cars.add("BMW");
       cars.add("VW");
       */
       //using the queue interface
      /* Queue<String>queue = new LinkedList<>();
        queue.offer("First");
        queue.offer("Second");
        queue.offer("Third");
        
        while (!queue.isEmpty()){
            System.out.println(queue.poll());
        
        }
        
       
       /*foreq(int i =0; i<cars.size();i++){
           System.out.println("Car at index "+ i+" is "+cars.get(i));
       }
       */
      
      
    
    }
    
}
