/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package car;

/**
 *
 * @author THAPELI
 */
public class Car {
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Car c1 = new Car();
        c1.brand = "Toyota";
        c1.color = "chrome black";
        c1.maxspeed = 220;
        c1.mileage = 50000;
        c1.model = "GD6";
        c1.displayInfo();
    }
    String brand;
   String model; 
   int maxspeed;
   String color;
   double mileage;
   
   void displayInfo(){
       System.out.println("brad :"+ brand);
   System.out.println("model :"+ model);
   System.out.println("maxpeed :"+ maxspeed +" km/h");
   System.out.println("color :"+ color);
    System.out.println("mileage :"+ mileage);
   }
}
