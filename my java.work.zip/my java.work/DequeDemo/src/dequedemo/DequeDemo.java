/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dequedemo;
import java.util.ArrayDeque;
import java.util.Deque;
/**
 *
 * @author THAPELI
 */
public class DequeDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Deque<String> deque = new ArrayDeque<>();

        // Adding elements
        deque.addFirst("A");
        deque.addLast("B");
        deque.offerFirst("C");
        deque.offerLast("D");

        // Accessing elements
        System.out.println("First Element: " + deque.peekFirst());
        System.out.println("Last Element: " + deque.peekLast());

        // Removing elements
        System.out.println("Removed First: " + deque.pollFirst());
        System.out.println("Removed Last: " + deque.pollLast());

        // Final Deque
        System.out.println("Elements Left After removal: " + deque);
    }
}        
        
        
        
    
    

