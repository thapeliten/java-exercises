/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package factorialcheck;

/**
 *
 * @author THAPELI
 */
import java.util.Scanner;
public class FactorialCheck {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      Scanner input = new Scanner(System.in);
      System.out.print("Enter a number: ");
     
       int num = input.nextInt();
       int result = (int)fact(num);
       
       System.out.println("Factorial of " + num + " is: " + result);
    }
    public static long  fact(int num){
     
        long factorial = 1;

        for (int i = 1; i <= num; i++) {
            factorial *= i;
        }
     return factorial;
    }
}
