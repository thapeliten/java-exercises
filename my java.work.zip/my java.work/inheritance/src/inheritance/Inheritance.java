package inheritance;

  

class Shapes {
    String name;

    Shapes(String name) {
        this.name = name;
    }

    double area() {
        return 0; // default
    }

    double perimeter() {
        return 0; // default
    }
}

class Circle extends Shapes {
    double radius;

    Circle(double radius) {
        super("Circle");
        this.radius = radius;
    }

    @Override
    double area() {
        return 3.1427 * radius * radius;
    }

    @Override
    double perimeter() {
        return 2 * 3.1427 * radius;
    }
}

class Triangle extends Shapes {
    double a, b, c, height;

    Triangle(double a, double b, double c, double height) {
        super("Triangle");
        this.a = a;
        this.b = b;
        this.c = c;
        this.height = height;
    }

    @Override
    double area() {
        return (b * height) / 2;
    }

    @Override
    double perimeter() {
        return a + b + c;
    }
}

class Square extends Shapes {
    double side;

    Square(double side) {
        super("Square");
        this.side = side;
    }

    @Override
    double area() {
        return side * side;
    }

    @Override
    double perimeter() {
        return 4 * side;
    }
}

public class Inheritance {
    public static void main(String[] args) {
        Circle circle = new Circle(5);
        System.out.println(circle.name + " \n area: " + circle.area());
        System.out.println(circle.name + " perimeter: " + circle.perimeter());

        Triangle triangle = new Triangle(3, 4, 5, 4);
        System.out.println(triangle.name + " \n area: " + triangle.area());
        System.out.println(triangle.name + " perimeter: " + triangle.perimeter());

        Square square = new Square(4);
        System.out.println(square.name + "\n area: " + square.area());
        System.out.println(square.name + " perimeter: " + square.perimeter());
    }
}


