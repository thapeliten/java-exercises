package pkgabstract;


// Abstract class
abstract class Shape {
   
    abstract void draw();

    
    void display() {
        System.out.println("This is a shape.");
    }
}


class Circle extends Shape {
    @Override
    void draw() {
        System.out.println("Drawing a Circle.");
    }
}

class Rectangle extends Shape {
    @Override
    void draw() {
        System.out.println("Drawing a Rectangle.");
    }
}


public class AbstractExample {
    public static void main(String[] args) {
        // important (Shape s = new Shape();  Not allowed (cannot instantiate abstract class))

        Shape c = new Circle();   // Upcasting
        c.display();              // from abstract class
        c.draw();                 // Circle’s implementation

        Shape r = new Rectangle();
        r.display();
        r.draw();
    }
}
