/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package anagrams;

/**
 *
 * @author THAPELI
 */
import java.util.Arrays;
public class Anagrams {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String word1 = "heart";
        String word2 = "earth";
        
        if(isAnagram(word1, word2)){
        System.out.println(word1 + " and " + word2 + " are anagrams.");
        }else{
        System.out.println(word1 + " and " + word2 + " are NOT anagrams.");
        }
    }
     public static boolean isAnagram(String str1, String str2) {
        // Remove spaces and make lowercase for fairness
        str1 = str1.replaceAll("\\s", "").toLowerCase();
        str2 = str2.replaceAll("\\s", "").toLowerCase();

        // If lengths differ, can't be an anagram
        if (str1.length() != str2.length()) {
            return false;
        }

        // Convert strings to char arrays and sort
        char[] arr1 = str1.toCharArray();
        char[] arr2 = str2.toCharArray();
        Arrays.sort(arr1);
        Arrays.sort(arr2);

        // Compare sorted arrays
        return Arrays.equals(arr1, arr2);
    }
}
