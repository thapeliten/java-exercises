/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package digitsadd;

/**
 *
 * @author THAPELI
 */
public class DigitsAdd {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int number = 12;
        int sum = 0;
        
        String numString = Integer.toString(number);
        for(int i = 0; i< numString.length();i++ ){
        char eachnum = numString.charAt(i);
        int digit = Character.getNumericValue(eachnum);
        sum += digit;
        
        
        }
      System.out.println("Sum of digits: " + sum); 
      String check = "12u4";
      char indi = check.charAt(2);
      int get = Character.getNumericValue(indi);
      System.out.println("the checked digit: " + get);
    }
    
}
