/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package animals2;

/**
 *
 * @author THAPELI
 */
public class Animals2 {
    void noise(){
 
 }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        dog sepoti =new dog();
        
        sepoti.noise();
        cat wiskers =new cat();
        
        wiskers.noise();
    }
    
}
class dog extends Animals2{
void noise(){
    System.out.println("barks ");
}

}
class cat extends Animals2{
void noise(){
    System.out.println("meow ");
}

}