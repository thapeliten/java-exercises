/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inheritance2;


public class Inheritance2 {
    public static void main(String[] args) {
      car car = new car();
      car.fuel();
      car.move();
      
      animal a = new cat();
     a.makeSound();
    }
}
