/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inheritance2;

/**
 *
 * @author THAPELI
 */
abstract public class animal {
    abstract void makeSound();
}

class cat extends animal{
    @Override
    void makeSound() {
         System.out.println("meow");
    }
}