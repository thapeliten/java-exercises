/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atm;

/**
 *
 * @author THAPELI
 */
import java.util.Scanner;
public class ATM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner option = new Scanner(System.in);
        int choice;
         do{
        
                    // Display the menu
            System.out.println("\n--- Welcome to MyATM! ---");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit Money");
            System.out.println("3. Withdraw Money");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
        
            
            while (!option.hasNextInt()) {
                System.out.println("\nInvalid input. Please enter a number between 1 and 5.");
                option.next(); // consume the invalid input
                System.out.print("Enter your choice: ");
            }
            
              choice = option.nextInt();
              
              switch(choice){
                  
                  case 1 -> {System.out.println("\nYou have selected to check balance");
                         
                         int pin ;
                         System.out.println("Enter PIN"); 
                         pin = option.nextInt();
                          
                          
              System.out.println("\nYour balance is M1000.00 ");
        }
                       
                  
                  
                  case 2 -> {System.out.println("\nYou have selected to deposit money");
                           int amount;
                           System.out.println("how much would you like you like to deposite");
                           amount = option.nextInt();
                           System.out.println("you have depositrd "+ amount +" you knew balnce is "+ amount+1000);
                           
                  }
                 case 3 -> {System.out.println("\nHow much would you like to withdraw?");
                            int withamount;
                            withamount = option.nextInt();
                            System.out.println("you have withdrew "+ withamount +" you knew balnce is "+""+ (1000-withamount));
                 }
                 
                 case 4 -> System.out.println("\nexiting menu and goodbye");
                 
                 default ->  System.out.println("\nInvalid choice. Please enter a number between 1 and 5.");
            
              }
         }while(choice!= 4);
         option.close();
          
        
           
              
            }     
    
    
    
    }
