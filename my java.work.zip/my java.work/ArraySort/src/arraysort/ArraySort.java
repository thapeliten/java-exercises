/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arraysort;

/**
 *
 * @author THAPELI
 */
import java.util.Arrays;
public class ArraySort {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] array = {9,8,7,6,5,4,3,2,1};
        
        Arrays.sort(array);
        
        System.out.println("sorted Array "+ Arrays.toString(array));
        
        //element search
        int  target = 7;
        for(int i = 0; i < array.length; i++){
         if(array[i]==target){
            System.out.println("Element found at index: "+ i +" element value is: "+ array[i]);
         }
        }
        
    }
    
}
