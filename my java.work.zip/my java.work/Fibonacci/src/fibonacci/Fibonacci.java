/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package fibonacci;

/**
 *
 * @author THAPELI
 */
import java.util.Scanner;
public class Fibonacci {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner nterm = new Scanner(System.in);
        int first = 0, second = 1;
        System.out.print(" \nenter number of terms");
        int term = nterm.nextInt();
        
        System.out.print("\nFibonacci Series up to " + term + " terms: ");
        
         for (int i = 0; i < term; i++) {
            System.out.print(first + " ");
            int next = first + second;
            first = second;
            second = next;
        }
        
        }
    }
    

